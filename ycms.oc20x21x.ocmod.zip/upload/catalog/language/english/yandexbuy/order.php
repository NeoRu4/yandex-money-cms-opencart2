<?php
$_['text_marketcpa_changeorder']            = "Yandex.Market transmitted the order to %s.";
$_['text_marketcpa_toprocessing']           = "You can change it to 'DELIVERY' (no more than 7 days) or to 'CANCELLED'";
$_['text_marketcpa_todelivery']             = "You can change it to 'PICKUP' (the order is in the pickup point) or to 'DELIVERED' (the order is handed to the buyer).";
