<?php

require_once dirname(__FILE__).DIRECTORY_SEPARATOR.'yamodule.php';

class ControllerPaymentYamoduleB2bSberbank extends ControllerPaymentYamodule
{
}

class ControllerExtensionPaymentYamoduleB2bSberbank extends ControllerPaymentYamoduleB2bSberbank
{
}