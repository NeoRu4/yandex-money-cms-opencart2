<?php
$_['heading_title']    = 'Сбербанк Бизнес Онлайн от Яндекс.Деньги';
$_['text_yandexmoney'] = '<a onclick="window.open(\'https://money.yandex.ru\');"><img src="view/image/payment/yandexmoney.png" alt="Яндекс.Деньги" title="Яндекс.Деньги" /></a>';